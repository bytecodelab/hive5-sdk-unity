using System;
using LitJson;

namespace Hive5.Models
{
	/// <summary>
	/// I hive5 result data.
	/// </summary>
	public interface IResponseBody
	{

	}
}

