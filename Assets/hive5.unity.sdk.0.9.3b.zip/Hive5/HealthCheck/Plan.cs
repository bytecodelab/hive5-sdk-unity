﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hive5
{
    public class Plan
    {
        public DateTime? StartAt { get; set; }

        public DateTime? EndAt { get; set; }

        public string Message { get; set; }
    }
}
