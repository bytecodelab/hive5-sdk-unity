﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hive5
{
    public class SpiderChannel
    {
        public long app_id { get; set; }

        public int channel_number { get; set; }

        public int session_count { get; set; }
    }
}
