using System;
using System.Collections.Generic;
using LitJson;
using Hive5;
using Hive5.Util;

namespace Hive5.Models
{
	/// <summary>
	/// Result of Apply Coupon
	/// </summary>
	public class RedeemCouponResponseBody : RunScriptResponseBody
	{
	}
}

